let trees = [];
let smokeClouds = [];
let gameState = "playing";
let treesPlanted = 0;

function setup() {
  createCanvas(800, 400);
}

function draw() {
  background(135, 206, 235);
 
  drawSun();
  drawClouds();
  drawCountryside();
  drawCity();
  drawSmoke();
  drawTrees();
  drawUI();

  if (gameState === "playing") {
    generateSmoke();
    moveSmoke();
    checkGameOver();
  }
}

// ------------------ CENÁRIO ------------------

function drawSun() {
  fill(255, 204, 0);
  noStroke();
  ellipse(100, 80, 60, 60);
}

function drawClouds() {
  fill(255);
  noStroke();
  for (let x = 150; x < width; x += 200) {
    ellipse(x, 80, 60, 60);
    ellipse(x + 30, 80, 60, 60);
    ellipse(x + 15, 60, 60, 60);
  }
}

function drawCountryside() {
  fill(34, 139, 34);
  rect(0, 250, 400, 150);
}

function drawCity() {
  for (let x = 450; x < width; x += 70) {
    fill(100);
    rect(x, 200, 60, 200);
    fill(255, 255, 100);
    for (let y = 210; y < 350; y += 30) {
      rect(x + 10, y, 10, 15);
      rect(x + 35, y, 10, 15);
    }
    fill(80);
    rect(x + 20, 180, 10, 20);
  }
}

// ------------------ ÁRVORES ------------------

function drawTrees() {
  for (let tree of trees) {
    fill(139, 69, 19);
    rect(tree.x - 5, tree.y, 10, 30);
    fill(34, 139, 34);
    ellipse(tree.x, tree.y, 40, 40);
  }
}

// ------------------ FUMAÇA ------------------

function generateSmoke() {
  if (frameCount % 30 === 0) {
    smokeClouds.push({
      x: random(450, width),
      y: random(180, 300),
      size: 20,
      alpha: 180
    });
  }
}

function drawSmoke() {
  for (let cloud of smokeClouds) {
    fill(80, cloud.alpha);
    noStroke();
    ellipse(cloud.x, cloud.y, cloud.size);
  }
}

function moveSmoke() {
  for (let cloud of smokeClouds) {
    cloud.x -= 0.5;
    cloud.y += random(-0.3, 0.3);
    cloud.size += 0.02;
    cloud.alpha -= 0.1;
  }
}

// ------------------ CLIQUE ------------------

function mousePressed() {
  if (gameState !== "playing") return;
  if (mouseX < 400 && mouseY > 250) {
    trees.push({ x: mouseX, y: mouseY - 20 });
    treesPlanted++;
  }
}

// ------------------ CONDIÇÕES DE FIM ------------------

function checkGameOver() {
  for (let cloud of smokeClouds) {
    if (cloud.x < 400 && cloud.alpha > 100) {
      gameState = "lost";
      return;
    }
  }

  if (treesPlanted >= 10) {
    gameState = "won";
  }
}

// ------------------ UI ------------------

function drawUI() {
  textSize(18);
  fill(0);
  textAlign(LEFT);
  text("Árvores plantadas: " + treesPlanted + "/10", 10, 20);

  textAlign(CENTER);
  textSize(32);
  if (gameState === "won") {
    text("Você purificou o campo! 🌱", width / 2, 50);
  } else if (gameState === "lost") {
    text("A poluição venceu! 💨", width / 2, 50);
  }
}

